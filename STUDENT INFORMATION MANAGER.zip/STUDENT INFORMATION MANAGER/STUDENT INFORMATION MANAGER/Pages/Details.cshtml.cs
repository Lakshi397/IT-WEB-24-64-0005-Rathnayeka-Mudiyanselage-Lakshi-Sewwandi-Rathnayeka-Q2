﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using STUDENT_INFORMATION_MANAGER.Data;
using STUDENT_INFORMATION_MANAGER.Pages.Models;

namespace STUDENT_INFORMATION_MANAGER.Pages
{
    public class DetailsModel : PageModel
    {
        private readonly STUDENT_INFORMATION_MANAGER.Data.STUDENT_INFORMATION_MANAGERContext _context;

        public DetailsModel(STUDENT_INFORMATION_MANAGER.Data.STUDENT_INFORMATION_MANAGERContext context)
        {
            _context = context;
        }

        public Add_New_Course_info Add_New_Couse_info { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var add_new_couse_info = await _context.Add_New_Couse_info.FirstOrDefaultAsync(m => m.ID == id);
            if (add_new_couse_info == null)
            {
                return NotFound();
            }
            else
            {
                Add_New_Couse_info = add_new_couse_info;
            }
            return Page();
        }
    }
}
