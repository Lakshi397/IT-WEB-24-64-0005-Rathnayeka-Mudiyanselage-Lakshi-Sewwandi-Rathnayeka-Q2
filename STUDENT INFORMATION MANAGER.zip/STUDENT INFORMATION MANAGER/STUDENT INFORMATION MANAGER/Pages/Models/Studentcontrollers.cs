﻿namespace STUDENT_INFORMATION_MANAGER.Pages.Models
{
    public class Studentcontrollers
    {
    }
}
