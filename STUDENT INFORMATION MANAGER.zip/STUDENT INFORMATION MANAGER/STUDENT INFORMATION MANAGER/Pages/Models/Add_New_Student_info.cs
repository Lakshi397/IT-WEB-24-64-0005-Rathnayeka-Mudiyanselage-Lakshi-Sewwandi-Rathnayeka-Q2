﻿namespace STUDENT_INFORMATION_MANAGER.Pages.Models
{
    public class Add_New_Student_info
    {
        public int ID { get; set; }
        public string First_Name { get; set; }
        public string Last_Name { get; set; }
        public int Age { get; set; }
        public string City { get; set; }
    }
}
