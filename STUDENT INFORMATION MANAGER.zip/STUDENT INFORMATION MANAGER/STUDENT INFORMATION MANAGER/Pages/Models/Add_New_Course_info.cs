﻿namespace STUDENT_INFORMATION_MANAGER.Pages.Models
{
    public class Add_New_Course_info
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Lecrurer_Name { get; set; }






    }
}
