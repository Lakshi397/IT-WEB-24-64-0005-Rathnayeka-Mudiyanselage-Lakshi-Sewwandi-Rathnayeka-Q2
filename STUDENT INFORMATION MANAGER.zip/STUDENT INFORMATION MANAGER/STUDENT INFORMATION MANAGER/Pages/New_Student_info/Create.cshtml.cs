﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using STUDENT_INFORMATION_MANAGER.Data;
using STUDENT_INFORMATION_MANAGER.Pages.Models;

namespace STUDENT_INFORMATION_MANAGER.Pages.New_Studen_info
{
    public class CreateModel : PageModel
    {
        private readonly STUDENT_INFORMATION_MANAGER.Data.STUDENT_INFORMATION_MANAGERContext _context;

        public CreateModel(STUDENT_INFORMATION_MANAGER.Data.STUDENT_INFORMATION_MANAGERContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]
        public Add_New_Student_info Add_New_Sudent_info { get; set; } = default!;

        // For more information, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Add_New_Sudent_info.Add(Add_New_Sudent_info);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
