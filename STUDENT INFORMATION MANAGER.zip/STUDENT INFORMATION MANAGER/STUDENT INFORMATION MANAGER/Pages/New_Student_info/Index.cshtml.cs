﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using STUDENT_INFORMATION_MANAGER.Data;
using STUDENT_INFORMATION_MANAGER.Pages.Models;

namespace STUDENT_INFORMATION_MANAGER.Pages.New_Studen_info
{
    public class IndexModel : PageModel
    {
        private readonly STUDENT_INFORMATION_MANAGER.Data.STUDENT_INFORMATION_MANAGERContext _context;

        public IndexModel(STUDENT_INFORMATION_MANAGER.Data.STUDENT_INFORMATION_MANAGERContext context)
        {
            _context = context;
        }

        public IList<Add_New_Student_info> Add_New_Sudent_info { get;set; } = default!;

        public async Task OnGetAsync()
        {
            Add_New_Sudent_info = await _context.Add_New_Sudent_info.ToListAsync();
        }
    }
}
