﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using STUDENT_INFORMATION_MANAGER.Pages.Models;

namespace STUDENT_INFORMATION_MANAGER.Data
{
    public class STUDENT_INFORMATION_MANAGERContext : DbContext
    {
        public STUDENT_INFORMATION_MANAGERContext (DbContextOptions<STUDENT_INFORMATION_MANAGERContext> options)
            : base(options)
        {
        }

        public DbSet<STUDENT_INFORMATION_MANAGER.Pages.Models.Add_New_Course_info> Add_New_Couse_info { get; set; } = default!;
        public DbSet<STUDENT_INFORMATION_MANAGER.Pages.Models.Add_New_Student_info> Add_New_Sudent_info { get; set; } = default!;
    }
}
